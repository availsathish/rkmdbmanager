import { useEffect, useState } from "react";
import { supabase } from "../supabase/client";

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [form, setForm] = useState({ company_name: "", address: "", city: "", mobile_number: "" });

  const fetchCustomers = async () => {
    const { data, error } = await supabase.from("customers").select("*").order("id", { ascending: false });
    if (!error) setCustomers(data);
  };

  useEffect(() => { fetchCustomers(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.company_name) return;
    await supabase.from("customers").insert([form]);
    setForm({ company_name: "", address: "", city: "", mobile_number: "" });
    fetchCustomers();
  };

  const handleDelete = async (id) => {
    await supabase.from("customers").delete().eq("id", id);
    fetchCustomers();
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold mb-4">Customers</h2>
      <form onSubmit={handleSubmit} className="space-y-2 mb-4">
        {["company_name", "address", "city", "mobile_number"].map((field) => (
          <input key={field}
            placeholder={field.replace("_", " ")}
            className="block w-full p-2 border rounded"
            value={form[field]} onChange={(e) => setForm({ ...form, [field]: e.target.value })} />
        ))}
        <button className="bg-blue-500 text-white px-4 py-2 rounded" type="submit">Add Customer</button>
      </form>
      <ul className="space-y-2">
        {customers.map((cust) => (
          <li key={cust.id} className="border p-2 rounded flex justify-between items-center">
            <div>
              <strong>{cust.company_name}</strong><br />
              <span>{cust.city} - {cust.mobile_number}</span>
            </div>
            <button onClick={() => handleDelete(cust.id)} className="text-red-500">🗑️</button>
          </li>
        ))}
      </ul>
    </div>
  );
}