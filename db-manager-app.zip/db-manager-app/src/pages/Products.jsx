import { useEffect, useState } from "react";
import { supabase } from "../supabase/client";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({ name: "", price: "" });
  const [image, setImage] = useState(null);

  const fetchProducts = async () => {
    const { data } = await supabase.from("products").select("*").order("id", { ascending: false });
    setProducts(data || []);
  };

  useEffect(() => { fetchProducts(); }, []);

  const handleUpload = async (file) => {
    const filename = `${Date.now()}_${file.name}`;
    const { error } = await supabase.storage.from("product-images").upload(filename, file);
    if (error) throw error;
    const { data } = supabase.storage.from("product-images").getPublicUrl(filename);
    return data.publicUrl;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let imageUrl = "";
    if (image) imageUrl = await handleUpload(image);
    await supabase.from("products").insert([{ ...form, image_url: imageUrl }]);
    setForm({ name: "", price: "" });
    setImage(null);
    fetchProducts();
  };

  const handleDelete = async (id) => {
    await supabase.from("products").delete().eq("id", id);
    fetchProducts();
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold mb-4">Products</h2>
      <form onSubmit={handleSubmit} className="space-y-2 mb-4">
        <input placeholder="Name" className="w-full p-2 border rounded"
          value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input placeholder="Price" className="w-full p-2 border rounded"
          value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
        <input type="file" accept="image/*" className="w-full" onChange={(e) => setImage(e.target.files[0])} />
        <button className="bg-green-500 text-white px-4 py-2 rounded" type="submit">Add Product</button>
      </form>
      <ul className="grid grid-cols-2 gap-4">
        {products.map((prod) => (
          <li key={prod.id} className="border p-2 rounded text-center">
            {prod.image_url && <img src={prod.image_url} alt="" className="h-24 object-cover mx-auto mb-2" />}
            <strong>{prod.name}</strong><br />
            ₹{prod.price}<br />
            <button onClick={() => handleDelete(prod.id)} className="text-red-500 mt-2">🗑️</button>
          </li>
        ))}
      </ul>
    </div>
  );
}